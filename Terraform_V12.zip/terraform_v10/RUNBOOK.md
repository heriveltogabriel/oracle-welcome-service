# Runbook - OCI Automatic Failover v10

## Estado normal

```text
Primary  = RUNNING / HEALTHY
Standby  = STOPPED
Alarm    = OK
```

## Verificar serviço da Primary

```bash
curl -i http://localhost/health-check
sudo systemctl status oracle-welcome --no-pager
sudo ss -lntp | grep ':80'
```

## Verificar Load Balancer

```text
10.0.1.238:80  backup=false -> OK
10.0.1.200:80  backup=true  -> unhealthy enquanto parada
```

## Verificar Alarm

```text
healthcheck-failover-alarm -> OK
```

## Teste de failover

1. Fazer `/health-check` retornar HTTP 500 na Primary.
2. Reiniciar `oracle-welcome`.
3. Confirmar `curl -i http://localhost/health-check` = 500.
4. Aguardar Primary = Critical no LB.
5. Aguardar Alarm = Firing.
6. Confirmar Function invocation.
7. Confirmar Standby = RUNNING.
8. Confirmar Standby backend = OK.

## Recuperação

Restaurar:

```python
self.send_response(HTTPStatus.OK)
```

Reiniciar:

```bash
sudo systemctl restart oracle-welcome
```

Confirmar:

```bash
curl -i http://localhost/health-check
```

Depois:

```text
Primary backend -> OK
Alarm -> OK
Standby -> STOPPED (estado normal)
```

## Observações

- Não criar OCI Health Check externo para esta arquitetura privada.
- Bastion é externo à stack e não é gerenciado pelo Terraform.
- A VCN e a subnet de aplicação existentes não são gerenciadas pelo Terraform.
- A imagem da Function precisa existir no OCIR antes do Apply.
