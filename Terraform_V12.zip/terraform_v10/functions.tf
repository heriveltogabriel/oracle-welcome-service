resource "oci_functions_application" "failover" {
  compartment_id = local.solution_compartment_ocid
  display_name   = "${var.name_prefix}-fn-app"
  subnet_ids                  = [data.oci_core_subnet.function.id]
  network_security_group_ids   = [oci_core_network_security_group.functions.id]
  shape                       = "GENERIC_X86"

  config = {
    STANDBY_INSTANCE_OCID = var.standby_instance_ocid
    OCI_REGION             = var.region
  }
}

resource "oci_functions_function" "start_standby" {
  application_id     = oci_functions_application.failover.id
  display_name       = "${var.name_prefix}-start-standby"
  image              = local.function_image
  memory_in_mbs      = local.function_memory_mbs
  timeout_in_seconds = local.function_timeout_seconds
}

resource "oci_ons_subscription" "function" {
  compartment_id = local.solution_compartment_ocid
  topic_id       = oci_ons_notification_topic.failover.id
  protocol       = "ORACLE_FUNCTIONS"
  endpoint       = oci_functions_function.start_standby.id
}

resource "oci_identity_dynamic_group" "function" {
  provider       = oci.home
  compartment_id = var.tenancy_ocid
  name           = "${var.name_prefix}-fn-dg"
  description    = "Dynamic group for the automatic failover Function."
  matching_rule  = "ALL {resource.type = 'fnfunc', resource.id = '${oci_functions_function.start_standby.id}'}"
}

resource "oci_identity_policy" "function" {
  provider       = oci.home
  compartment_id = var.tenancy_ocid
  name           = "${var.name_prefix}-fn-policy"
  description    = "Least-privilege runtime policy for the automatic failover Function."

  statements = [
    "Allow dynamic-group ${oci_identity_dynamic_group.function.name} to use instance-family in compartment id ${local.compute_compartment_ocid}",
    "Allow service faas to read repos in tenancy"
  ]
}
