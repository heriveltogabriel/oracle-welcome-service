# For a private-only architecture the standard OCI Health Checks external HTTP
# monitor is not used because OCI-managed public vantage points cannot reach
# the customer's private LB IP. The LB's native backend health check publishes
# oci_lbaas metrics, which Monitoring evaluates.

resource "oci_ons_notification_topic" "failover" {
  compartment_id = local.solution_compartment_ocid
  name           = "${var.name_prefix}-topic"
  description    = "Automatic failover notifications for ${var.name_prefix}."
}

resource "oci_monitoring_alarm" "failover" {
  compartment_id               = local.solution_compartment_ocid
  display_name                 = "${var.name_prefix}-alarm"
  is_enabled                   = true
  metric_compartment_id        = local.solution_compartment_ocid
  namespace                    = "oci_lbaas"
  query                        = "unhealthyBackendServers[1m]{lbName = \"${oci_load_balancer_load_balancer.this.display_name}\", backendSetName = \"${oci_load_balancer_backend_set.application.name}\"}.max() >= ${local.alarm_unhealthy_backend_threshold}"
  severity                     = "CRITICAL"
  destinations                 = [oci_ons_notification_topic.failover.id]
  pending_duration             = local.alarm_pending_duration
  repeat_notification_duration = local.alarm_repeat_notification_duration
  message_format               = "RAW"
  notification_title           = "${var.name_prefix}: all backends unhealthy"
  alarm_summary                = "The private Load Balancer reports both application backends as unhealthy. The standby VM should be started."
  body                         = "Automatic failover detected from the Load Balancer backend health metric. Check the primary and standby VMs."

  is_notifications_per_metric_dimension_enabled = false
}

resource "oci_logging_log_group" "functions" {
  compartment_id = local.solution_compartment_ocid
  display_name   = "${var.name_prefix}-logs"
  description    = "Logs for OCI Functions used by the failover solution."
}

resource "oci_logging_log" "function_invoke" {
  display_name        = "${var.name_prefix}-function-invoke"
  log_group_id        = oci_logging_log_group.functions.id
  log_type            = "SERVICE"
  is_enabled          = true
  retention_duration  = local.log_retention_days

  configuration {
    source {
      category    = "invoke"
      resource    = oci_functions_application.failover.id
      service     = "functions"
      source_type = "OCISERVICE"
    }
  }
}
