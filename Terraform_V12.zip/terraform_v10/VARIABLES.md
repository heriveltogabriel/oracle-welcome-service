# Variables - OCI Automatic Failover v10

Todos os campos aparecem como editaveis no OCI Resource Manager. A v10 vem com valores sugeridos ja preenchidos para o ambiente validado em Sao Paulo/Vinhedo. Revise os OCIDs especificos do ambiente antes do Apply.

## Obrigatorios - editaveis e pre-preenchidos

| Variavel | Sugestao | Finalidade |
|---|---|---|
| region | sa-vinhedo-1 | Regiao dos recursos da solucao |
| home_region | sa-saopaulo-1 | Regiao home para recursos IAM |
| tenancy_ocid | OCID da tenancy validada | Tenancy onde a solucao sera criada |
| primary_instance_ocid | OCID da Primary validada | VM existente usada como backend principal |
| standby_instance_ocid | OCID da Standby validada | VM existente usada como backend de backup |
| name_prefix | healthcheck-failover | Prefixo dos nomes dos recursos |
| function_image | vcp.ocir.io/grhyd8rovlum/failover/start-standby:1.0.0 | Imagem da OCI Function no OCIR |

## Opcionais - editaveis e pre-preenchidos

| Variavel | Sugestao |
|---|---|
| compartment_ocid | Compartment usado no ambiente validado |
| function_subnet_ocid | null (reuses the primary VM subnet) |
| application_port | 80 |
| healthcheck_path | /health-check |
| backend_healthcheck_interval_ms | 10000 |
| backend_healthcheck_timeout_ms | 5000 |
| alarm_unhealthy_backend_threshold | 2 |
| alarm_pending_duration | PT1M |
| alarm_repeat_notification_duration | PT30M |
| load_balancer_min_bandwidth_mbps | 10 |
| load_balancer_max_bandwidth_mbps | 100 |
| function_memory_mbs | 256 |
| function_timeout_seconds | 120 |
| log_retention_days | 30 |

> Os sete campos obrigatorios continuam editaveis. Eles possuem valores sugeridos para facilitar a instalacao, mas devem ser revisados quando o pacote for usado em outra tenancy ou em outro ambiente.
