resource "oci_load_balancer_load_balancer" "this" {
  compartment_id            = local.solution_compartment_ocid
  display_name              = "${var.name_prefix}-lb"
  shape                     = "flexible"
  is_private                = true
  subnet_ids                = [data.oci_core_subnet.application.id]
  network_security_group_ids = [oci_core_network_security_group.load_balancer.id]
  is_request_id_enabled     = true

  shape_details {
    minimum_bandwidth_in_mbps = local.load_balancer_min_bandwidth_mbps
    maximum_bandwidth_in_mbps = local.load_balancer_max_bandwidth_mbps
  }

  freeform_tags = {
    solution = "oci-automatic-failover"
    managed  = "terraform"
  }
}

resource "oci_load_balancer_backend_set" "application" {
  load_balancer_id = oci_load_balancer_load_balancer.this.id
  name             = "application"
  policy           = "LEAST_CONNECTIONS"

  health_checker {
    protocol            = "HTTP"
    port                = local.application_port
    url_path            = local.healthcheck_path
    interval_ms         = local.backend_healthcheck_interval_ms
    timeout_in_millis   = local.backend_healthcheck_timeout_ms
    retries             = 3
    return_code         = 200
    is_force_plain_text = true
  }
}

resource "oci_load_balancer_backend" "primary" {
  load_balancer_id = oci_load_balancer_load_balancer.this.id
  backendset_name  = oci_load_balancer_backend_set.application.name
  ip_address       = data.oci_core_vnic.primary.private_ip_address
  port             = local.application_port
  weight           = 1
  backup           = false
  drain            = false
  offline          = false
}

resource "oci_load_balancer_backend" "standby" {
  load_balancer_id = oci_load_balancer_load_balancer.this.id
  backendset_name  = oci_load_balancer_backend_set.application.name
  ip_address       = data.oci_core_vnic.standby.private_ip_address
  port             = local.application_port
  weight           = 1
  backup           = true
  drain            = false
  offline          = false
}

