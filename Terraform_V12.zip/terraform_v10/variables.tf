variable "region" {
  type        = string
  description = "[OBRIGATORIO - EDITAVEL] OCI region where the solution resources are created. Suggested: sa-vinhedo-1."
  default     = "sa-vinhedo-1"
}

variable "home_region" {
  type        = string
  description = "[OBRIGATORIO - EDITAVEL] Tenancy home region used for IAM resources. Suggested: sa-saopaulo-1."
  default     = "sa-saopaulo-1"
}

variable "tenancy_ocid" {
  type        = string
  description = "[OBRIGATORIO - EDITAVEL] Tenancy OCID. Suggested value is from the validated environment."
  default     = "ocid1.tenancy.oc1..aaaaaaaahe3myxlyq42k7mxyir5csvcnlfxhxyt63qitq52hg2ctp53y2f2q"
}

variable "compartment_ocid" {
  type        = string
  description = "[OPCIONAL - EDITAVEL] Compartment for new solution resources. Suggested: the existing application compartment."
  default     = "ocid1.compartment.oc1..aaaaaaaadkfiexnctrnmmciq6q26am6rzzimwgxz65icg74uanpzlms5jisa"
}

variable "primary_instance_ocid" {
  type        = string
  description = "[OBRIGATORIO - EDITAVEL] OCID of the existing primary VM. Suggested value is from the validated environment."
  default     = "ocid1.instance.oc1.sa-vinhedo-1.an3ggljrwnykn6acynccdpb5w4wkxbk6xxv2pb73y6bx4wuw5izhptwr7fga"
}

variable "standby_instance_ocid" {
  type        = string
  description = "[OBRIGATORIO - EDITAVEL] OCID of the existing standby VM. Suggested value is from the validated environment."
  default     = "ocid1.instance.oc1.sa-vinhedo-1.an3ggljrwnykn6acad4ahylu3mc3rrpw65ipekpm655r4cfwtqlfcmnn654a"
}

variable "name_prefix" {
  type        = string
  description = "[OBRIGATORIO - EDITAVEL] Prefix used for resource names. Suggested: healthcheck-failover."
  default     = "healthcheck-failover"
}

variable "function_image" {
  type        = string
  description = "[OBRIGATORIO - EDITAVEL] Full OCIR image reference already pushed to the registry. Suggested: vcp.ocir.io/grhyd8rovlum/failover/start-standby:1.0.0"
  default     = "vcp.ocir.io/grhyd8rovlum/failover/start-standby:1.0.0"
}

variable "function_subnet_ocid" {
  type        = string
  description = "[OPCIONAL - EDITAVEL] OCID of the existing subnet where the private Function Application will run. If left empty, the primary VM application subnet is reused."
  default     = null
}

variable "application_port" {
  type        = number
  description = "[OPCIONAL - EDITAVEL] TCP port exposed by both existing VMs. Suggested: 80."
  default     = 80
}

variable "healthcheck_path" {
  type        = string
  description = "[OPCIONAL - EDITAVEL] Application health endpoint used by the Load Balancer health checker. Suggested: /health-check."
  default     = "/health-check"
}

variable "backend_healthcheck_interval_ms" {
  type        = number
  description = "[OPCIONAL - EDITAVEL] Load Balancer backend health check interval in milliseconds. Suggested: 10000."
  default     = 10000
}

variable "backend_healthcheck_timeout_ms" {
  type        = number
  description = "[OPCIONAL - EDITAVEL] Load Balancer backend health check timeout in milliseconds. Suggested: 5000."
  default     = 5000
}

variable "alarm_unhealthy_backend_threshold" {
  type        = number
  description = "[OPCIONAL - EDITAVEL] Number of unhealthy backends required to fire the alarm. This version supports exactly 2 backend VMs. Suggested: 2."
  default     = 2

  validation {
    condition     = var.alarm_unhealthy_backend_threshold == 2
    error_message = "This solution expects exactly two backend VMs; alarm_unhealthy_backend_threshold must be 2."
  }
}

variable "alarm_pending_duration" {
  type        = string
  description = "[OPCIONAL - EDITAVEL] Alarm pending duration in ISO-8601 format. Suggested: PT1M."
  default     = "PT1M"
}

variable "alarm_repeat_notification_duration" {
  type        = string
  description = "[OPCIONAL - EDITAVEL] Repeated notification interval while the alarm remains firing. Suggested: PT30M."
  default     = "PT30M"
}

variable "load_balancer_min_bandwidth_mbps" {
  type        = number
  description = "[OPCIONAL - EDITAVEL] Minimum bandwidth for the flexible private Load Balancer shape. Suggested: 10 Mbps."
  default     = 10
}

variable "load_balancer_max_bandwidth_mbps" {
  type        = number
  description = "[OPCIONAL - EDITAVEL] Maximum bandwidth for the flexible private Load Balancer shape. Suggested: 100 Mbps."
  default     = 100
}

variable "function_memory_mbs" {
  type        = number
  description = "[OPCIONAL - EDITAVEL] OCI Functions memory allocation in MB. Suggested: 256 MB."
  default     = 256
}

variable "function_timeout_seconds" {
  type        = number
  description = "[OPCIONAL - EDITAVEL] OCI Functions timeout in seconds. Suggested: 120 seconds."
  default     = 120
}

variable "log_retention_days" {
  type        = number
  description = "[OPCIONAL - EDITAVEL] Function log retention in days. Suggested: 30."
  default     = 30

  validation {
    condition     = contains([30, 60, 90, 120, 150, 180], var.log_retention_days)
    error_message = "log_retention_days must be one of 30, 60, 90, 120, 150 or 180."
  }
}
