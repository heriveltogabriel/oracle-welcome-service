terraform {
  required_version = ">= 1.5.0"

  required_providers {
    oci = {
      source  = "oracle/oci"
      version = ">= 8.0.0, < 9.0.0"
    }
  }
}

provider "oci" {
  region = var.region
}

# IAM is tenancy-scoped. Using the home-region provider avoids the common
# Resource Manager/OCI IAM regional mismatch seen when the stack runs in a
# region different from the tenancy home region.
provider "oci" {
  alias  = "home"
  region = var.home_region
}
