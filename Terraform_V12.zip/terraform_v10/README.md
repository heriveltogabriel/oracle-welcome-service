# Terraform_V10

Pacote Terraform para provisionar a solução OCI Automatic Failover V10.

Inclui somente os arquivos Terraform e o exemplo de variáveis para uso no OCI Resource Manager.

Pré-requisitos: as duas VMs Primary e Standby já devem existir. O Bastion não faz parte desta solução Terraform.
