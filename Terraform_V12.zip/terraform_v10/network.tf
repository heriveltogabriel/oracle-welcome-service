# Existing VCN and application subnet are discovered from the primary VM.
# Terraform does not manage or replace them. The Function Application reuses
# an existing subnet (explicit OCID or the primary VM subnet by default).

resource "oci_core_service_gateway" "functions" {
  count          = local.existing_service_gateway_id == null ? 1 : 0
  compartment_id = local.network_compartment_ocid
  vcn_id         = data.oci_core_vcn.application.id
  display_name   = "${var.name_prefix}-service-gateway"

  services {
    service_id = data.oci_core_services.all_region_services.services[0].id
  }
}

resource "oci_core_network_security_group" "load_balancer" {
  compartment_id = local.network_compartment_ocid
  vcn_id         = data.oci_core_vcn.application.id
  display_name    = "${var.name_prefix}-lb-nsg"
}

resource "oci_core_network_security_group" "functions" {
  compartment_id = local.network_compartment_ocid
  vcn_id         = data.oci_core_vcn.application.id
  display_name    = "${var.name_prefix}-fn-nsg"
}

resource "oci_core_network_security_group_security_rule" "lb_egress_to_backends" {
  network_security_group_id = oci_core_network_security_group.load_balancer.id
  direction                 = "EGRESS"
  protocol                  = "6"
  destination               = data.oci_core_vcn.application.cidr_block
  destination_type          = "CIDR_BLOCK"
  stateless                 = false
  description               = "Allow Load Balancer to reach application backends"

  tcp_options {
    destination_port_range {
      min = local.application_port
      max = local.application_port
    }
  }
}

resource "oci_core_network_security_group_security_rule" "functions_egress_dns_tcp" {
  network_security_group_id = oci_core_network_security_group.functions.id
  direction                 = "EGRESS"
  protocol                  = "6"
  destination               = "169.254.169.254/32"
  destination_type          = "CIDR_BLOCK"
  stateless                 = false
  description               = "Allow Function DNS resolution over TCP"

  tcp_options {
    destination_port_range {
      min = 53
      max = 53
    }
  }
}

resource "oci_core_network_security_group_security_rule" "functions_egress_dns_udp" {
  network_security_group_id = oci_core_network_security_group.functions.id
  direction                 = "EGRESS"
  protocol                  = "17"
  destination               = "169.254.169.254/32"
  destination_type          = "CIDR_BLOCK"
  stateless                 = false
  description               = "Allow Function DNS resolution over UDP"

  udp_options {
    destination_port_range {
      min = 53
      max = 53
    }
  }
}

resource "oci_core_network_security_group_security_rule" "functions_egress_oci_services" {
  network_security_group_id = oci_core_network_security_group.functions.id
  direction                 = "EGRESS"
  protocol                  = "6"
  destination               = data.oci_core_services.all_region_services.services[0].cidr_block
  destination_type          = "SERVICE_CIDR_BLOCK"
  stateless                 = false
  description               = "Allow Function to reach OCI services through Service Gateway"

  tcp_options {
    destination_port_range {
      min = 443
      max = 443
    }
  }
}

# If the existing VMs already use NSGs, authorize the Terraform-managed
# Load Balancer NSG to reach the application port. If they do not use NSGs,
# this resource simply has no instances and the existing subnet Security List
# is expected to allow the application port.
resource "oci_core_network_security_group_security_rule" "existing_vm_ingress" {
  for_each = local.application_nsg_ids

  network_security_group_id = each.value
  direction                 = "INGRESS"
  protocol                  = "6"
  source                    = oci_core_network_security_group.load_balancer.id
  source_type               = "NETWORK_SECURITY_GROUP"
  stateless                 = false
  description               = "Allow failover Load Balancer to reach existing application VM"

  tcp_options {
    destination_port_range {
      min = local.application_port
      max = local.application_port
    }
  }
}
