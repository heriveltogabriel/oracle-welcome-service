# OCI Function - Start Standby

Arquivos da Function de failover extraidos do pacote Terraform v6.

A Function usa Resource Principal e espera a configuracao `STANDBY_INSTANCE_OCID`.

Build alvo: `linux/amd64` / OCI Functions `GENERIC_X86`.
