import json
import logging
import os

import oci
from fdk import response


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def handler(ctx, data=None):
    instance_id = os.environ["STANDBY_INSTANCE_OCID"]
    region = os.environ["OCI_REGION"]

    signer = oci.auth.signers.get_resource_principals_signer()
    compute = oci.core.ComputeClient(config={"region": region}, signer=signer)

    instance = compute.get_instance(instance_id).data
    previous_state = instance.lifecycle_state

    logger.info(
        "standby_instance=%s previous_state=%s event=%s",
        instance_id,
        previous_state,
        _read_event(data),
    )

    if previous_state == "STOPPED":
        compute.instance_action(instance_id, "START")
        result = {
            "action": "START",
            "instance_ocid": instance_id,
            "previous_state": previous_state,
        }
        logger.info("instance_action=%s", json.dumps(result))
    else:
        result = {
            "action": "noop",
            "instance_ocid": instance_id,
            "previous_state": previous_state,
        }
        logger.info("instance_action=%s", json.dumps(result))

    return response.Response(
        ctx,
        response_data=json.dumps(result),
        headers={"Content-Type": "application/json"},
    )


def _read_event(data):
    if data is None:
        return None
    try:
        raw = data.read()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        return json.loads(raw) if raw else None
    except Exception:
        logger.exception("Unable to parse notification event")
        return None
