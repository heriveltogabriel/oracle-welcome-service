# Function_V10

Código da OCI Function `start-standby` usado pela solução Automatic Failover V10.

Arquivos:
- func.py
- func.yaml
- requirements.txt
- Dockerfile
- README_FUNCTION.md
