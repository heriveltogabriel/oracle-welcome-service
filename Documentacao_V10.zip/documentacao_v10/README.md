# OCI Automatic Failover - Terraform v10 Final

Solução final do laboratório de failover automático com **duas VMs existentes**, **Private Load Balancer**, **Monitoring Alarm**, **Notifications** e **OCI Functions**.

Esta versão é **unidirecional**: a Primary é a ativa; a Standby fica parada. Quando o Load Balancer detecta que os dois backends estão não íntegros, o Alarm publica no Notifications Topic e a Function inicia a Standby.

> A versão de failover flutuante (Primary <-> Standby) fica propositalmente fora desta v10 para uma evolução futura.

## Pré-requisitos assumidos

As VMs e o Bastion já existem. Esta stack não cria nem gerencia o Bastion.

As VMs devem:

- existir na mesma VCN;
- usar o serviço web na porta 80;
- expor `/health-check` com HTTP 200 quando saudáveis;
- ter IPs privados estáveis conhecidos pela descoberta via VNIC;
- ter a Standby normalmente em `STOPPED`.

A subnet das VMs é descoberta a partir da Primary. O Load Balancer privado é criado nessa subnet existente. A stack não assume posse da VCN nem da subnet existente.

## O que o Terraform cria

- Private Load Balancer regional.
- Backend Set `application`.
- Backend Primary com `backup = false`.
- Backend Standby com `backup = true`.
- Health checker HTTP `/health-check` na porta 80.
- Alarm de Monitoring usando `oci_lbaas.unhealthyBackendServers`.
- Notifications Topic.
- Subscription `ORACLE_FUNCTIONS` apontando para a Function.
- OCI Functions Application e Function `GENERIC_X86`.
- Subnet privada dedicada para Functions.
- Route Table para Service Gateway.
- Service Gateway somente se a VCN ainda não tiver um adequado.
- NSG do Load Balancer.
- NSG da Function.
- Regras de DNS/HTTPS de saída da Function.
- Dynamic Group e IAM Policy para Resource Principal.
- Log Group e Service Log da Function.

## O que o Terraform NÃO cria

- VMs.
- Bastion.
- VCN existente.
- Subnet de aplicação existente.
- NAT Gateway existente.
- Regras da Security List da subnet da aplicação.
- Repositório OCIR.

## Arquitetura

```text
                         +-------------------------+
                         | Private Load Balancer   |
                         | health-check: :80       |
                         +------------+------------+
                                      |
                       +--------------+--------------+
                       |                             |
                       v                             v
              +----------------+            +----------------+
              | PRIMARY        |            | STANDBY        |
              | 10.0.1.238:80  |            | 10.0.1.200:80  |
              | backup=false   |            | backup=true    |
              | RUNNING        |            | STOPPED        |
              +-------+--------+            +-------+--------+
                      |                             |
                      +---------------+-------------+
                                      |
                                      v
                             unhealthyBackendServers
                                      |
                                      v
                              Monitoring Alarm
                                      |
                                      v
                            Notifications Topic
                                      |
                                      v
                               OCI Function
                                      |
                                      v
                          Compute API -> START Standby
```

O backend marcado como `backup = true` não recebe tráfego enquanto existir backend não-backup saudável. Isso permite manter a Standby desligada sem torná-la o destino normal do LB. citeturn188669search2

## Observação sobre Health Checks

Não crie um monitor externo em **Observability & Management > Health Checks** para esta solução. O monitoramento usado pela automação é o health checker nativo do Backend Set do Load Balancer. A métrica `unhealthyBackendServers` representa o número de backends não íntegros no backend set. citeturn188669search2turn188669search3

## Arquivo de configuração

A configuração é feita pelas variáveis Terraform. No OCI Resource Manager, todos os parâmetros aparecem como campos editáveis; os parâmetros marcados como `[OBRIGATORIO]` precisam ser informados e os `[OPCIONAL]` podem permanecer vazios, usando o comportamento padrão documentado.

O pacote não inclui um `terraform.tfvars` carregado automaticamente pelo Resource Manager. Os valores das variáveis Terraform já vêm pré-definidos no código como sugestões editáveis; revise especialmente tenancy, compartment, Primary, Standby e imagem da Function antes do Apply. O `terraform.tfvars.example` replica as sugestões para uso via CLI.
