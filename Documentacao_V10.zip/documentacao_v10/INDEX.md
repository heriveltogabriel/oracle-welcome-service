# Documentacao_V10

Documentação de entrega da solução OCI Automatic Failover V10.

- README.md: visão geral
- TUTORIAL.md: implantação passo a passo
- VARIABLES.md: parâmetros editáveis do Terraform / Resource Manager
- RUNBOOK.md: operação e testes
- arquitetura_v10.png: diagrama da arquitetura
