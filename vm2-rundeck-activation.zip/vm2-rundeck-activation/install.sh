#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTIVATOR_SOURCE="${SCRIPT_DIR}/activate-rundeck-failover.sh"
SERVICE_SOURCE="${SCRIPT_DIR}/activate-rundeck-failover.service"
README_SOURCE="${SCRIPT_DIR}/README.md"
ACTIVATOR_TARGET="/usr/local/sbin/activate-rundeck-failover.sh"
SERVICE_TARGET="/etc/systemd/system/activate-rundeck-failover.service"
CONFIG_DIR="/etc/failover"
CONFIG_FILE="${CONFIG_DIR}/activate.env"
DOC_DIR="/usr/local/share/doc/vm2-rundeck-activation"
CONFIG_TMP=""

cleanup() {
  if [[ -n "${CONFIG_TMP}" && -f "${CONFIG_TMP}" ]]; then
    rm -f "${CONFIG_TMP}"
  fi
}
trap cleanup EXIT

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Execute como root: sudo bash install.sh"
  exit 1
fi

for command_name in curl install systemctl; do
  if ! command -v "${command_name}" >/dev/null 2>&1; then
    echo "Comando obrigatorio nao encontrado: ${command_name}"
    exit 1
  fi
done

for source_file in "${ACTIVATOR_SOURCE}" "${SERVICE_SOURCE}" "${README_SOURCE}"; do
  if [[ ! -f "${source_file}" ]]; then
    echo "Arquivo do pacote nao encontrado: ${source_file}"
    exit 1
  fi
done

install -d -m 0700 -o root -g root "${CONFIG_DIR}"
install -d -m 0755 -o root -g root "${DOC_DIR}"
install -m 0750 -o root -g root "${ACTIVATOR_SOURCE}" "${ACTIVATOR_TARGET}"
install -m 0644 -o root -g root "${SERVICE_SOURCE}" "${SERVICE_TARGET}"
install -m 0644 -o root -g root "${README_SOURCE}" "${DOC_DIR}/README.md"

if [[ -f "${CONFIG_FILE}" ]]; then
  chown root:root "${CONFIG_FILE}"
  chmod 0600 "${CONFIG_FILE}"
  echo "Configuracao existente preservada em ${CONFIG_FILE}."
else
  if [[ ! -t 0 ]]; then
    echo "A instalacao inicial precisa de um terminal para solicitar o token sem exibi-lo."
    echo "Execute: sudo bash install.sh"
    exit 1
  fi

  read -r -s -p "Informe um NOVO token do Rundeck: " rundeck_token
  echo

  if [[ -z "${rundeck_token}" ]]; then
    echo "O token nao pode ficar vazio."
    exit 1
  fi

  if [[ ! "${rundeck_token}" =~ ^[A-Za-z0-9._~+/=-]+$ ]]; then
    echo "O token contem caracteres nao suportados pelo arquivo de configuracao."
    exit 1
  fi

  CONFIG_TMP="$(mktemp "${CONFIG_DIR}/activate.env.XXXXXX")"
  chmod 0600 "${CONFIG_TMP}"
  chown root:root "${CONFIG_TMP}"
  {
    printf 'RUNDECK_AUTH_TOKEN=%s\n' "${rundeck_token}"
    printf '%s\n' 'RUNDECK_URL=http://127.0.0.1:3105/api/57/system/executions/enable'
    printf '%s\n' 'RETRY_SECONDS=30'
    printf '%s\n' 'CONNECT_TIMEOUT=5'
    printf '%s\n' 'REQUEST_TIMEOUT=15'
  } >"${CONFIG_TMP}"
  mv "${CONFIG_TMP}" "${CONFIG_FILE}"
  CONFIG_TMP=""
  echo "Configuracao criada em ${CONFIG_FILE}."
fi

systemctl daemon-reload
systemctl enable activate-rundeck-failover.service
systemctl restart --no-block activate-rundeck-failover.service

echo
echo "Instalacao concluida. A ativacao foi iniciada em segundo plano."
echo "Acompanhar: sudo journalctl -u activate-rundeck-failover.service -f"
echo "Ver status: sudo systemctl status activate-rundeck-failover.service --no-pager"
