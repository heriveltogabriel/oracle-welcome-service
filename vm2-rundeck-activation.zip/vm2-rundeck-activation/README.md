# Ativacao do Rundeck na VM2 de failover

Este pacote instala um servico `systemd` que, em toda inicializacao da VM2, chama a API local do Rundeck para habilitar o modo de execucao.

## Comportamento

O servico envia um `POST` para:

```text
http://127.0.0.1:3105/api/57/system/executions/enable
```

A ativacao so e considerada concluida quando as duas condicoes abaixo forem atendidas:

- o endpoint retornar HTTP entre `200` e `299`;
- o JSON retornado contiver `"executionMode":"active"`.

Se a porta ainda nao estiver disponivel, ocorrer timeout, o HTTP nao for `2xx` ou o JSON nao confirmar `active`, o script aguarda 30 segundos e tenta novamente. Depois do sucesso, ele encerra e nao chama mais o endpoint ate o proximo boot.

## Arquivos instalados

```text
/usr/local/sbin/activate-rundeck-failover.sh
/etc/systemd/system/activate-rundeck-failover.service
/etc/failover/activate.env
/usr/local/share/doc/vm2-rundeck-activation/README.md
```

O arquivo `/etc/failover/activate.env` pertence a `root`, usa permissao `0600` e nao deve ser enviado ao Git.

## Antes de instalar

Revogue qualquer token que tenha sido compartilhado em conversa, chamado, documentacao ou log. Crie um token novo exclusivamente para esta automacao e conceda somente as permissoes necessarias para habilitar o modo de execucao.

A VM precisa ter:

- Linux com `systemd`;
- `curl` instalado;
- Rundeck escutando localmente na porta `3105`.

## Instalacao

Copie a pasta `vm2-rundeck-activation` para a VM2 e execute:

```bash
cd vm2-rundeck-activation
sudo bash install.sh
```

Na primeira instalacao, o instalador solicita o token sem exibi-lo na tela e sem grava-lo no historico do shell. Em seguida, ele instala os arquivos, habilita o servico para os proximos boots e inicia a primeira tentativa em segundo plano.

Se `/etc/failover/activate.env` ja existir, o instalador preserva a configuracao atual.

## Acompanhar a ativacao

Ver logs em tempo real:

```bash
sudo journalctl -u activate-rundeck-failover.service -f
```

Ver o estado atual:

```bash
sudo systemctl status activate-rundeck-failover.service --no-pager
```

Quando funcionar, o log apresentara uma mensagem semelhante a:

```text
Sucesso: HTTP 200; executionMode=active confirmado.
```

O status esperado depois do sucesso e `active (exited)`. Isso significa que a chamada terminou corretamente e nao sera repetida naquele boot.

## Operacao manual

Executar novamente agora:

```bash
sudo systemctl restart --no-block activate-rundeck-failover.service
```

Interromper as tentativas:

```bash
sudo systemctl stop activate-rundeck-failover.service
```

Desabilitar nos proximos boots:

```bash
sudo systemctl disable --now activate-rundeck-failover.service
```

Habilitar novamente:

```bash
sudo systemctl enable --now activate-rundeck-failover.service
```

## Trocar o token

Edite o arquivo protegido:

```bash
sudo vi /etc/failover/activate.env
```

Altere apenas o valor de `RUNDECK_AUTH_TOKEN`, salve e aplique:

```bash
sudo chown root:root /etc/failover/activate.env
sudo chmod 600 /etc/failover/activate.env
sudo systemctl restart --no-block activate-rundeck-failover.service
```

## Parametros

O arquivo `/etc/failover/activate.env` aceita:

```text
RUNDECK_AUTH_TOKEN=<token_novo>
RUNDECK_URL=http://127.0.0.1:3105/api/57/system/executions/enable
RETRY_SECONDS=30
CONNECT_TIMEOUT=5
REQUEST_TIMEOUT=15
```

- `RETRY_SECONDS`: intervalo entre as tentativas.
- `CONNECT_TIMEOUT`: limite em segundos para estabelecer a conexao.
- `REQUEST_TIMEOUT`: limite total de cada chamada HTTP.

Todos os valores numericos devem ser inteiros maiores que zero.

## Diagnostico

### Conexao recusada ou timeout

Confirme se o Rundeck esta ouvindo na porta local:

```bash
sudo ss -ltnp | grep ':3105'
curl -i --connect-timeout 5 http://127.0.0.1:3105/
```

O script continuara tentando enquanto o endpoint estiver indisponivel.

### HTTP 401 ou 403

O token esta invalido, expirado ou sem permissao. Gere outro token, atualize `/etc/failover/activate.env` e reinicie a unidade.

### HTTP 2xx sem `executionMode=active`

A API respondeu, mas nao confirmou a ativacao. Consulte o log do Rundeck e confirme a versao e o caminho da API. O script continuara tentando.

### `curl` nao encontrado

No Oracle Linux, instale com:

```bash
sudo dnf install -y curl
```

Depois execute novamente `sudo bash install.sh`.

## Remocao

```bash
sudo systemctl disable --now activate-rundeck-failover.service
sudo rm /etc/systemd/system/activate-rundeck-failover.service
sudo rm /usr/local/sbin/activate-rundeck-failover.sh
sudo rm -r /usr/local/share/doc/vm2-rundeck-activation
sudo systemctl daemon-reload
```

O arquivo com o token nao e removido automaticamente. Depois de confirmar que nao sera mais necessario:

```bash
sudo rm /etc/failover/activate.env
sudo rmdir /etc/failover 2>/dev/null || true
```
