#!/usr/bin/env python3
import json
import pathlib
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer


port_file = pathlib.Path(sys.argv[1])
count_file = pathlib.Path(sys.argv[2])


class Handler(BaseHTTPRequestHandler):
    request_count = 0

    def do_POST(self):
        Handler.request_count += 1
        count_file.write_text(str(Handler.request_count), encoding="utf-8")

        if self.path != "/api/57/system/executions/enable":
            status = 404
            payload = {"message": "not found"}
        elif self.headers.get("X-Rundeck-Auth-Token") != "test-token":
            status = 403
            payload = {"message": "forbidden"}
        elif Handler.request_count == 1:
            status = 503
            payload = {"executionMode": "passive"}
        else:
            status = 200
            payload = {"executionMode": "active"}

        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        return


server = HTTPServer(("127.0.0.1", 0), Handler)
port_file.write_text(str(server.server_port), encoding="utf-8")
server.serve_forever()
