#!/usr/bin/env bash
set -euo pipefail

TEST_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${TEST_DIR}/.." && pwd)"
ACTIVATOR="${PROJECT_DIR}/activate-rundeck-failover.sh"
TMP_DIR="$(mktemp -d)"
SERVER_PID=""

cleanup() {
  if [[ -n "${SERVER_PID}" ]] && kill -0 "${SERVER_PID}" 2>/dev/null; then
    kill "${SERVER_PID}" 2>/dev/null || true
    wait "${SERVER_PID}" 2>/dev/null || true
  fi
  rm -rf "${TMP_DIR}"
}
trap cleanup EXIT

PORT_FILE="${TMP_DIR}/port"
COUNT_FILE="${TMP_DIR}/count"
OUTPUT_FILE="${TMP_DIR}/output"

python3 "${TEST_DIR}/mock_rundeck_server.py" "${PORT_FILE}" "${COUNT_FILE}" &
SERVER_PID=$!

for _ in $(seq 1 50); do
  [[ -s "${PORT_FILE}" ]] && break
  sleep 0.1
done

if [[ ! -s "${PORT_FILE}" ]]; then
  echo "FAIL: servidor de teste nao iniciou"
  exit 1
fi

PORT="$(<"${PORT_FILE}")"

RUNDECK_AUTH_TOKEN="test-token" \
RUNDECK_URL="http://127.0.0.1:${PORT}/api/57/system/executions/enable" \
RETRY_SECONDS=1 \
CONNECT_TIMEOUT=2 \
REQUEST_TIMEOUT=2 \
bash "${ACTIVATOR}" >"${OUTPUT_FILE}" 2>&1

if [[ "$(<"${COUNT_FILE}")" != "2" ]]; then
  echo "FAIL: esperado 2 chamadas; recebido $(<"${COUNT_FILE}")"
  sed -n '1,120p' "${OUTPUT_FILE}"
  exit 1
fi

if ! grep -q "executionMode=active confirmado" "${OUTPUT_FILE}"; then
  echo "FAIL: log de confirmacao nao encontrado"
  sed -n '1,120p' "${OUTPUT_FILE}"
  exit 1
fi

if grep -q "test-token" "${OUTPUT_FILE}"; then
  echo "FAIL: token encontrado nos logs"
  exit 1
fi

echo "PASS: ativacao repetiu e confirmou executionMode=active"
