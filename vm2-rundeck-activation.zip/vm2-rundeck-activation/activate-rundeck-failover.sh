#!/usr/bin/env bash
set -uo pipefail

RUNDECK_URL="${RUNDECK_URL:-http://127.0.0.1:3105/api/57/system/executions/enable}"
RETRY_SECONDS="${RETRY_SECONDS:-30}"
CONNECT_TIMEOUT="${CONNECT_TIMEOUT:-5}"
REQUEST_TIMEOUT="${REQUEST_TIMEOUT:-15}"
RUNDECK_AUTH_TOKEN="${RUNDECK_AUTH_TOKEN:-}"

log() {
  printf '%s %s\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$*"
}

require_positive_integer() {
  local name="$1"
  local value="$2"

  if [[ ! "${value}" =~ ^[1-9][0-9]*$ ]]; then
    log "ERRO: ${name} deve ser um numero inteiro maior que zero."
    exit 2
  fi
}

if ! command -v curl >/dev/null 2>&1; then
  log "ERRO: curl nao esta instalado."
  exit 2
fi

if [[ -z "${RUNDECK_AUTH_TOKEN}" || "${RUNDECK_AUTH_TOKEN}" == "SUBSTITUA_POR_UM_TOKEN_NOVO" ]]; then
  log "ERRO: RUNDECK_AUTH_TOKEN nao foi configurado."
  exit 2
fi

if [[ ! "${RUNDECK_AUTH_TOKEN}" =~ ^[A-Za-z0-9._~+/=-]+$ ]]; then
  log "ERRO: RUNDECK_AUTH_TOKEN contem caracteres nao suportados."
  exit 2
fi

if [[ ! "${RUNDECK_URL}" =~ ^https?:// ]]; then
  log "ERRO: RUNDECK_URL deve comecar com http:// ou https://."
  exit 2
fi

require_positive_integer "RETRY_SECONDS" "${RETRY_SECONDS}"
require_positive_integer "CONNECT_TIMEOUT" "${CONNECT_TIMEOUT}"
require_positive_integer "REQUEST_TIMEOUT" "${REQUEST_TIMEOUT}"

WORK_DIR="$(mktemp -d)"
RESPONSE_FILE="${WORK_DIR}/response.json"
ERROR_FILE="${WORK_DIR}/curl-error.log"
CURL_CONFIG_FILE="${WORK_DIR}/curl.conf"

cleanup() {
  rm -rf "${WORK_DIR}"
}
trap cleanup EXIT

chmod 0700 "${WORK_DIR}"
umask 077
printf 'header = "X-Rundeck-Auth-Token: %s"\n' "${RUNDECK_AUTH_TOKEN}" >"${CURL_CONFIG_FILE}"

attempt=0
log "Iniciando ativacao do Rundeck em ${RUNDECK_URL}."

while true; do
  attempt=$((attempt + 1))
  : >"${RESPONSE_FILE}"
  : >"${ERROR_FILE}"
  log "Tentativa ${attempt}: solicitando executionMode=active."

  http_code=""
  if http_code="$(curl \
    --config "${CURL_CONFIG_FILE}" \
    --silent \
    --show-error \
    --request POST \
    --output "${RESPONSE_FILE}" \
    --write-out '%{http_code}' \
    --connect-timeout "${CONNECT_TIMEOUT}" \
    --max-time "${REQUEST_TIMEOUT}" \
    "${RUNDECK_URL}" \
    2>"${ERROR_FILE}")"; then
    if [[ "${http_code}" =~ ^2[0-9][0-9]$ ]] \
      && LC_ALL=C grep -Eq '"executionMode"[[:space:]]*:[[:space:]]*"active"' "${RESPONSE_FILE}"; then
      log "Sucesso: HTTP ${http_code}; executionMode=active confirmado."
      exit 0
    fi

    if [[ ! "${http_code}" =~ ^2[0-9][0-9]$ ]]; then
      log "Tentativa ${attempt} sem sucesso: HTTP ${http_code}."
    else
      log "Tentativa ${attempt} sem sucesso: resposta HTTP ${http_code} sem executionMode=active."
    fi
  else
    curl_error="$(tr '\n' ' ' <"${ERROR_FILE}" | cut -c1-300)"
    log "Tentativa ${attempt} sem sucesso: falha de conexao (${curl_error:-erro desconhecido})."
  fi

  log "Nova tentativa em ${RETRY_SECONDS} segundos."
  sleep "${RETRY_SECONDS}"
done
