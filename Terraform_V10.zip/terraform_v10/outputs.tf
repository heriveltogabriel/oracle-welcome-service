output "vcn_ocid" {
  value = data.oci_core_vcn.application.id
}

output "application_subnet_ocid" {
  value = data.oci_core_subnet.application.id
}

output "primary_private_ip" {
  value = data.oci_core_vnic.primary.private_ip_address
}

output "standby_private_ip" {
  value = data.oci_core_vnic.standby.private_ip_address
}

output "load_balancer_ocid" {
  value = oci_load_balancer_load_balancer.this.id
}

output "load_balancer_private_ips" {
  value = [for x in oci_load_balancer_load_balancer.this.ip_address_details : x.ip_address if !x.is_public]
}

output "load_balancer_private_url" {
  value = "http://${oci_load_balancer_load_balancer.this.ip_address_details[0].ip_address}${local.healthcheck_path}"
}

output "backend_set_name" {
  value = oci_load_balancer_backend_set.application.name
}

output "alarm_id" {
  value = oci_monitoring_alarm.failover.id
}

output "alarm_query" {
  value = oci_monitoring_alarm.failover.query
}

output "notification_topic_id" {
  value = oci_ons_notification_topic.failover.id
}

output "function_application_id" {
  value = oci_functions_application.failover.id
}

output "function_id" {
  value = oci_functions_function.start_standby.id
}

output "function_subscription_id" {
  value = oci_ons_subscription.function.id
}

output "dynamic_group_id" {
  value = oci_identity_dynamic_group.function.id
}

output "dynamic_group_matching_rule" {
  value = oci_identity_dynamic_group.function.matching_rule
}

output "iam_policy_statements" {
  value = oci_identity_policy.function.statements
}

output "function_repository" {
  value = "failover/start-standby"
}

output "function_image" {
  value = local.function_image
}

output "function_subnet_ocid" {
  value = oci_core_subnet.functions.id
}

output "service_gateway_ocid" {
  value = local.service_gateway_id
}
