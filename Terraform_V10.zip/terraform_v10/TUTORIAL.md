# Tutorial completo - OCI Automatic Failover v10

## 1. Objetivo

Construir uma solução em que:

```text
NORMAL
Primary = RUNNING / HEALTHY
Standby = STOPPED
Alarm   = OK
```

Quando a aplicação da Primary deixa de responder ao health check:

```text
Primary = UNHEALTHY
Standby = STOPPED / UNHEALTHY
              |
              v
      Alarm = FIRING
              |
              v
        Notifications
              |
              v
          OCI Function
              |
              v
     START Standby VM
```

A Function usa Resource Principal para chamar a Compute API. Para Functions privadas, a aplicação deve usar uma subnet privada com caminho para os serviços Oracle via Service Gateway; a documentação da OCI descreve esse modelo de acesso privado. citeturn474350search0turn474350search1

## 2. Pré-requisitos

Esta documentação parte de um ambiente no qual os seguintes itens já existem:

```text
Primary VM
Standby VM
Bastion para administração
VCN
Subnet de aplicação
Internet Gateway/NAT Gateway/Service Gateway conforme o ambiente
```

A Primary e a Standby são descobertas pelos OCIDs informados nos campos correspondentes do OCI Resource Manager.

Para este laboratório, usamos:

```text
Region:       sa-vinhedo-1
Home region:  sa-saopaulo-1
Primary IP:   10.0.1.238
Standby IP:   10.0.1.200
Port:         80
Health path: /health-check
```

## 3. Preparar a imagem da OCI Function

A imagem precisa existir no OCIR antes do Apply do Resource Manager.

O pacote usa:

```text
vcp.ocir.io/grhyd8rovlum/failover/start-standby:1.0.0
```

### 3.1 Criar o repositório

No OCI Console:

```text
Developer Services
  -> Containers & Artifacts
  -> Container Registry
  -> Repositories
  -> Create Repository
```

Use:

```text
Repository: failover/start-standby
Visibility: Private
```

A stack não cria o repositório porque a Function precisa conseguir referenciar uma imagem já publicada.

### 3.2 Usar uma VM Linux x86 para o build

Para reproduzir exatamente o alvo da Function, use uma VM Linux x86/amd64.

Confirme:

```bash
uname -m
```

Esperado:

```text
x86_64
```

Instale Docker conforme o procedimento padrão da distribuição.

### 3.3 Copiar a pasta da Function

A estrutura é:

```text
function/
├── Dockerfile
├── func.py
├── func.yaml
└── requirements.txt
```

A Function usa:

```text
Python 3.12
OCI SDK
Fn FDK
Resource Principal
```

### 3.4 Autenticar no OCIR

Obtenha o namespace:

```bash
oci os ns get --query data --raw-output
```

Defina:

```bash
export OCIR_NAMESPACE="grhyd8rovlum"
export OCIR_USERNAME="${OCIR_NAMESPACE}/<seu-usuario-oci>"
export OCIR_AUTH_TOKEN="<seu-auth-token>"
```

O usuário precisa usar um Auth Token para o login no registry.

### 3.5 Build e push

Do diretório raiz do pacote:

```bash
./scripts/build-and-push-function.sh
```

O script executa:

```text
Docker login
Build --platform linux/amd64
Push
```

A imagem final deve existir em:

```text
vcp.ocir.io/grhyd8rovlum/failover/start-standby:1.0.0
```

A rede privada da Function precisa conseguir acessar o OCIR por Service Gateway quando a aplicação estiver em subnet privada. A OCI recomenda rota para `All <region> Services In Oracle Services Network` e regra de saída compatível. citeturn474350search2turn474350search6

## 4. Validar a Function localmente

A imagem é uma OCI Function e não deve ser testada apenas com `docker run` sem o runtime de Functions, porque o FDK espera `FN_LISTENER` no ambiente de execução.

O teste funcional real deve ser feito depois que a Function estiver publicada no OCI Functions.

## 5. Preparar o Terraform

O diretório contém:

```text
versions.tf
variables.tf
terraform.tfvars.example
data.tf
network.tf
load_balancer.tf
functions.tf
observability.tf
outputs.tf
```

A stack descobre:

```text
Primary instance -> VNIC -> subnet -> VCN
Standby instance -> VNIC -> subnet -> VCN
```

A validação garante que Primary e Standby estejam na mesma VCN e tenham IPs privados diferentes.

## 6. Preencher os parâmetros no OCI Resource Manager

Ao criar ou atualizar a Stack, preencha os campos exibidos pelo Resource Manager.

Campos obrigatórios:

- `region`
- `home_region`
- `tenancy_ocid`
- `primary_instance_ocid`
- `standby_instance_ocid`
- `name_prefix`
- `function_image`

Campos opcionais: `compartment_ocid`, `function_subnet_cidr`, `application_port`, `healthcheck_path`, `backend_healthcheck_interval_ms`, `backend_healthcheck_timeout_ms`, `alarm_unhealthy_backend_threshold`, `alarm_pending_duration`, `alarm_repeat_notification_duration`, `load_balancer_min_bandwidth_mbps`, `load_balancer_max_bandwidth_mbps`, `function_memory_mbs`, `function_timeout_seconds` e `log_retention_days`.

Quando um campo opcional ficar vazio, a solução aplica o valor padrão documentado na descrição da variável.

O pacote não contém credenciais, chave privada ou valores específicos do ambiente.

## 7. Como funciona a rede

A VCN e a subnet existente da aplicação ficam fora do gerenciamento do Terraform.

A stack cria somente uma subnet privada dedicada para Functions.

O fluxo dessa subnet é:

```text
Function subnet
      |
Route Table
      |
Service Gateway
      |
Oracle Services Network
      |
OCI APIs / OCIR
```

Um Service Gateway permite acesso privado a serviços Oracle suportados sem passar pela internet pública. citeturn474350search5

Se já existir Service Gateway adequado na VCN, a stack reutiliza o existente. Caso contrário, cria um.

## 8. Security Lists e NSGs

A stack cria NSGs próprios para:

```text
Load Balancer
Function
```

Se as VMs já possuírem NSGs, o Terraform adiciona nesses NSGs uma regra de entrada permitindo que o NSG do Load Balancer alcance a porta da aplicação.

Se as VMs não possuírem NSGs, o Terraform não cria um NSG artificial para elas e não altera a Security List existente da subnet de aplicação.

Nesse laboratório, a Security List existente já permite TCP/80, portanto a Primary pôde ser validada pelo Load Balancer.

A própria OCI observa que Security Lists são aplicadas no nível da subnet, enquanto NSGs são associados a VNICs; as duas formas podem coexistir. citeturn474350search8

## 9. Rodar Terraform localmente (opcional)

Se quiser validar o código antes do Resource Manager:

```bash
terraform init
terraform plan -out tfplan
terraform apply tfplan
```

O Resource Manager executa esse mesmo ciclo no serviço gerenciado.

## 10. Usar o OCI Resource Manager

No Console:

```text
Developer Services
  -> Resource Manager
  -> Stacks
  -> Create Stack
```

Escolha upload de ZIP e envie o pacote final.

Depois:

```text
Plan
```

Antes do Apply, confirme que:

```text
Primary e Standby aparecem apenas como data sources
Não existe oci_core_instance para as VMs
Não existe oci_bastion_bastion
Não há recursos de Bastion na lista
```

A criação esperada inclui, entre outros:

```text
Private Load Balancer
Backend Set
2 Backends
Function subnet
Function application
Function
Dynamic Group
Policy
Notifications Topic
Subscription
Alarm
Logs
```

## 11. Apply

Depois de validar o Plan:

```text
Apply
```

O primeiro Apply pode levar alguns minutos porque o OCI Functions Application, Load Balancer, Notifications e Bastion externo são componentes assíncronos; nesta v10 o Bastion não é gerenciado pela stack.

## 12. Validar o Load Balancer

Abra:

```text
Networking
  -> Load Balancers
  -> healthcheck-failover-lb
  -> Backend sets
  -> application
  -> Backends
```

O estado normal esperado é:

```text
10.0.1.238:80  Backup=False  -> OK
10.0.1.200:80  Backup=True   -> Warning/Connection failed
```

Isso é esperado porque a Standby está parada.

O backend marcado como `backup=true` só recebe tráfego quando os backends não-backup falham na política de health check. citeturn188669search2

## 13. Validar o Alarm

Abra:

```text
Observability & Management
  -> Monitoring
  -> Alarm Definitions
  -> healthcheck-failover-alarm
```

Estado normal:

```text
OK
```

A expressão usada é baseada em:

```text
unhealthyBackendServers[1m]
```

A métrica `unhealthyBackendServers` é a quantidade de backends não íntegros no backend set. citeturn188669search3

Com dois backends:

```text
Primary healthy
Standby unhealthy
=> 1 unhealthy
=> Alarm OK
```

O alarm só dispara quando:

```text
2 unhealthy
```

## 14. Validar a Function

No OCI:

```text
Developer Services
  -> Functions
  -> Applications
  -> healthcheck-failover-fn-app
```

Dentro dela:

```text
healthcheck-failover-start-standby
```

A Function usa:

```text
STANDBY_INSTANCE_OCID
OCI_REGION
```

A autenticação é feita com Resource Principal, então não há chave privada armazenada na imagem.

A Function consulta o estado da Standby e só chama `START` quando o estado anterior for `STOPPED`.

## 15. Teste controlado do failover

### Estado inicial

```text
Primary  -> RUNNING
Standby  -> STOPPED
Primary  -> /health-check = 200
Alarm    -> OK
```

### Forçar falha na Primary

No servidor Primary, a aplicação usada neste laboratório possui dois caminhos de teste:

```text
/health-check        -> 200
/health-check-error  -> 500
```

No código da aplicação, os caminhos saudáveis respondem `HTTPStatus.OK` e os caminhos de erro respondem `HTTPStatus.INTERNAL_SERVER_ERROR`.

Para testar exatamente o health check configurado pelo Load Balancer, altere temporariamente o handler de `/health-check` para devolver `500` e reinicie:

```bash
sudo systemctl restart oracle-welcome
```

Confirme localmente:

```bash
curl -i http://localhost/health-check
```

Esperado:

```text
HTTP/1.0 500 Internal Server Error
```

A documentação do backend set do Load Balancer confirma que o health checker usa o protocolo, porta e path configurados no backend set. citeturn188669search2

### Observar o fluxo

1. O Load Balancer passa a marcar Primary como `Critical`.
2. A Standby continua `STOPPED` e não saudável.
3. O contador de unhealthy backends chega a `2`.
4. O Alarm passa para `Firing` depois do pending duration.
5. Notifications publica no Topic.
6. A subscription `ORACLE_FUNCTIONS` invoca a Function. Uma Function subscription é justamente o mecanismo suportado pela OCI para invocar uma Function a partir de uma mensagem publicada em um topic. citeturn188669search0
7. A Function chama `ComputeClient.instance_action(..., "START")` para a Standby.
8. A Standby passa para `STARTING` e depois `RUNNING`.
9. O serviço web sobe.
10. O Load Balancer passa a marcar a Standby como `OK`.

## 16. Restaurar a Primary

Volte o código da Primary para:

```python
self.send_response(HTTPStatus.OK)
```

Depois:

```bash
sudo systemctl restart oracle-welcome
curl -i http://localhost/health-check
```

Esperado:

```text
HTTP/1.0 200 OK
```

Aguarde o Load Balancer reconhecer a Primary novamente como `OK`.

## 17. Estado final desejado

Depois de testar:

```text
Primary  -> RUNNING / HEALTHY
Standby  -> STOPPED
Alarm    -> OK
```

Se a Standby ainda estiver ligada depois do teste, pare manualmente a VM após confirmar que a Primary voltou a ficar saudável.

## 18. Outputs importantes

Ao final, o Resource Manager mostra outputs para:

```text
vcn_ocid
application_subnet_ocid
primary_private_ip
standby_private_ip
load_balancer_ocid
load_balancer_private_ips
load_balancer_private_url
backend_set_name
alarm_id
alarm_query
notification_topic_id
function_application_id
function_id
function_subscription_id
dynamic_group_id
dynamic_group_matching_rule
function_repository
function_image
function_subnet_ocid
service_gateway_ocid
```

## 19. Troubleshooting rápido

### Primary fica Critical mesmo com serviço ativo

Na Primary:

```bash
curl -i http://localhost/health-check
sudo ss -lntp | grep ':80'
```

O serviço precisa estar ouvindo em `0.0.0.0:80`, e o endpoint precisa retornar 200.

### Backend Set fica Warning

É normal quando a Primary está `OK` e a Standby está `STOPPED`.

Veja o estado individual dos dois backends antes de considerar isso um problema. A OCI define `Warning` para um backend set em que pelo menos um backend está OK e pelo menos um está em condição não-OK. citeturn188669search10

### Alarm não dispara

Confirme:

```text
Primary = unhealthy
Standby = unhealthy
```

Com dois backends, o threshold deve ser `2`.

### Function não é invocada

Verifique:

```text
Notifications Topic
Subscription protocol = ORACLE_FUNCTIONS
Subscription endpoint = Function OCID
```

A subscription de Function não exige confirmação manual. citeturn188669search0

### Function dá NotAuthorizedOrNotFound

Confira a Dynamic Group e a Policy criadas pela stack. A Function precisa de autorização para consultar e iniciar a Standby.

## 20. Limites intencionais da v10

Esta versão implementa **failover Primary -> Standby**.

Ela não implementa:

```text
Standby -> Primary automático
active/standby flutuante
failback automático
cooldown/histerese
lock distribuído
state machine para múltiplas transições
```

Esses pontos ficam reservados para a próxima evolução da arquitetura.
