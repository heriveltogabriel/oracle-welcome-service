# Existing infrastructure discovery. The user provides only the two instance OCIDs;
# Terraform discovers their compartments, VNICs, subnets and VCN automatically.

data "oci_core_instance" "primary" {
  instance_id = var.primary_instance_ocid
}

data "oci_core_instance" "standby" {
  instance_id = var.standby_instance_ocid
}

data "oci_core_vnic_attachments" "primary" {
  compartment_id = data.oci_core_instance.primary.compartment_id
  instance_id    = var.primary_instance_ocid
}

data "oci_core_vnic_attachments" "standby" {
  compartment_id = data.oci_core_instance.standby.compartment_id
  instance_id    = var.standby_instance_ocid
}

data "oci_core_vnic" "primary" {
  vnic_id = one([for a in data.oci_core_vnic_attachments.primary.vnic_attachments : a.vnic_id if a.nic_index == 0])
}

data "oci_core_vnic" "standby" {
  vnic_id = one([for a in data.oci_core_vnic_attachments.standby.vnic_attachments : a.vnic_id if a.nic_index == 0])
}

data "oci_core_subnet" "application" {
  subnet_id = data.oci_core_vnic.primary.subnet_id
}

data "oci_core_subnet" "standby" {
  subnet_id = data.oci_core_vnic.standby.subnet_id
}

data "oci_core_vcn" "application" {
  vcn_id = data.oci_core_subnet.application.vcn_id
}

data "oci_core_service_gateways" "existing" {
  compartment_id = local.network_compartment_ocid
  vcn_id         = data.oci_core_vcn.application.id
  state          = "AVAILABLE"
}

data "oci_core_services" "all_region_services" {
  filter {
    name   = "name"
    values = ["All .* Services In Oracle Services Network"]
    regex  = true
  }
}

locals {
  solution_compartment_ocid = coalesce(var.compartment_ocid, data.oci_core_instance.primary.compartment_id)
  network_compartment_ocid  = data.oci_core_vcn.application.compartment_id
  compute_compartment_ocid  = data.oci_core_instance.standby.compartment_id

  existing_service_gateway_id = try(data.oci_core_service_gateways.existing.service_gateways[0].id, null)
  service_gateway_id = coalesce(
    local.existing_service_gateway_id,
    try(oci_core_service_gateway.functions[0].id, null)
  )

  function_image       = var.function_image
  function_subnet_cidr = var.function_subnet_cidr

  application_port                   = coalesce(var.application_port, 80)
  healthcheck_path                   = coalesce(var.healthcheck_path, "/health-check")
  backend_healthcheck_interval_ms    = coalesce(var.backend_healthcheck_interval_ms, 10000)
  backend_healthcheck_timeout_ms     = coalesce(var.backend_healthcheck_timeout_ms, 5000)
  alarm_unhealthy_backend_threshold  = coalesce(var.alarm_unhealthy_backend_threshold, 2)
  alarm_pending_duration             = coalesce(var.alarm_pending_duration, "PT1M")
  alarm_repeat_notification_duration = coalesce(var.alarm_repeat_notification_duration, "PT30M")
  load_balancer_min_bandwidth_mbps   = coalesce(var.load_balancer_min_bandwidth_mbps, 10)
  load_balancer_max_bandwidth_mbps   = coalesce(var.load_balancer_max_bandwidth_mbps, 100)
  function_memory_mbs                = coalesce(var.function_memory_mbs, 256)
  function_timeout_seconds           = coalesce(var.function_timeout_seconds, 120)
  log_retention_days                 = coalesce(var.log_retention_days, 30)

  application_nsg_ids = toset(concat(
    data.oci_core_vnic.primary.nsg_ids,
    data.oci_core_vnic.standby.nsg_ids,
  ))
}

resource "terraform_data" "validate_network" {
  lifecycle {
    precondition {
      condition     = data.oci_core_subnet.application.vcn_id == data.oci_core_subnet.standby.vcn_id
      error_message = "Primary and standby instances must belong to the same VCN."
    }
    precondition {
      condition     = data.oci_core_vnic.primary.private_ip_address != data.oci_core_vnic.standby.private_ip_address
      error_message = "Primary and standby instances must have different private IP addresses."
    }
    precondition {
      condition     = data.oci_core_subnet.application.availability_domain == null || data.oci_core_subnet.application.availability_domain == ""
      error_message = "The primary VM subnet must be a regional subnet because it is reused by the private regional Load Balancer."
    }
    precondition {
      condition = local.existing_service_gateway_id == null || anytrue([
        for s in try(data.oci_core_service_gateways.existing.service_gateways[0].services, []) :
        can(regex("(?i)^All .* Services In Oracle Services Network$", s.service_name))
      ])
      error_message = "The existing VCN Service Gateway must allow All <region> Services in Oracle Services Network. Terraform will not modify an existing Service Gateway."
    }
  }
}
